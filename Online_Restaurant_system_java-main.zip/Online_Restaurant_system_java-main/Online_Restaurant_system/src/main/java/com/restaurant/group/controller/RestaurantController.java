package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Restaurant;
import com.restaurant.group.servicelayer.RestaurantService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class RestaurantController 
{
	@Autowired
	RestaurantService restoservice;
	
	@GetMapping("/restaurants")
	public List<Restaurant> getRestaurants()
	{
		return restoservice.getAllRestaurants();
	}
	
	@GetMapping("/restaurant/{id}")
	public Restaurant getRestaurant(@PathVariable(value = "id") Integer id)
	{
		return restoservice.getRestaurant(id);
	}
	
	@PostMapping("/addrestaurant")
	public Restaurant addRestaurant(@RequestBody Restaurant restaurant)
	{
		return restoservice.addRestaurant(restaurant);
	}
	
	@DeleteMapping("/removerestaurant/{id}")
	public Boolean removeRestaurant(@PathVariable(value = "id") Integer id)
	{
		if(restoservice.removeRestaurant(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleterestaurant")
	public boolean deleteRestaurantProduct(@RequestParam(value = "id") int id)
	{
		return restoservice.deleteRestaurant(id);
	}
	
	@PutMapping("/updaterestaurant/{id}")
	public Boolean updateRestaurant(@RequestBody Restaurant restaurant, @PathVariable(value = "id") Integer id)
	{
		if(restoservice.updateRestaurant(restaurant, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
