package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.WebsiteAdmin;
import com.restaurant.group.servicelayer.WebsiteAdminService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class WebsiteAdminController 
{
	@Autowired
	WebsiteAdminService websiteAdminService;

	@GetMapping("/websiteadmin")
	public List<WebsiteAdmin> getWebsiteAdmin() 
	{
		return websiteAdminService.getWebsiteAdmins();
	}
	
	@GetMapping("/adminlogin")
	public WebsiteAdmin webAdminLogin(@RequestParam String user_id,@RequestParam String password)
	{
		WebsiteAdmin admin=websiteAdminService.WebsiteAdminLogin(user_id);
		if(admin!=null)
		{
			return admin;
		}
		else
		{
			return new WebsiteAdmin();
		}
		
	}
	
	@PostMapping("/addadmin")
	public void addWebsiteAdmin(@RequestBody WebsiteAdmin admin)
	{
		websiteAdminService.addWebsiteAdmin(admin);
	}
	
	@DeleteMapping("/removeadmin/{id}")
	public Boolean removeWebsiteAdmin(@PathVariable(value = "id") Integer id)
	{
		if(websiteAdminService.removeWebsiteAdmin(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@PutMapping("/updateadmin/{id}")
	public Boolean updateWebsiteAdmin(@RequestBody WebsiteAdmin admin, @PathVariable(value = "id") Integer id)
	{
		if(websiteAdminService.updateWebsiteAdmin(admin, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
