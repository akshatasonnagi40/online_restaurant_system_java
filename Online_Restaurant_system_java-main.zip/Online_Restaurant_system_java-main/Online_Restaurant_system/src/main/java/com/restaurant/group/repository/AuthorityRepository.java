package com.restaurant.group.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.restaurant.group.entities.Authority;


@Repository
public interface AuthorityRepository extends JpaRepository<Authority, Integer> 
{
	@Query(value = "SELECT * FROM authority WHERE email = :email",nativeQuery = true)
	public Authority authoriryLogin(@Param("email") String email);
	
	public Authority findByEmail(String email);
}

