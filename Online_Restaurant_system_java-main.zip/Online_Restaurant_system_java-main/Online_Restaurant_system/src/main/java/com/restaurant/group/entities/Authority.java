package com.restaurant.group.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "authority")
public class Authority 
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int authority_id;

	@Column
	private String contact_no;
	
	@Column
	private String email;

	@Column
	private String first_nm;

	@Column
	private String last_nm;
	
	@Column
	private String password;
	
	

	
	@OneToOne
	@JoinColumn(name="restaurant_id")
	private Restaurant restaurant;


	@OneToOne
	@JoinColumn(name="role_id")
	private Roles role;


	public Authority() 
	{
		super();
	}



	public int getAuthority_id() {
		return authority_id;
	}


	public void setAuthority_id(int authority_id) {
		this.authority_id = authority_id;
	}


	public String getContact_no() {
		return contact_no;
	}


	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getFirst_nm() {
		return first_nm;
	}


	public void setFirst_nm(String first_nm) {
		this.first_nm = first_nm;
	}


	public String getLast_nm() {
		return last_nm;
	}


	public void setLast_nm(String last_nm) {
		this.last_nm = last_nm;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}


	public Roles getRole() {
		return role;
	}


	public void setRole(Roles role) {
		this.role = role;
	}
	
	
	

}

