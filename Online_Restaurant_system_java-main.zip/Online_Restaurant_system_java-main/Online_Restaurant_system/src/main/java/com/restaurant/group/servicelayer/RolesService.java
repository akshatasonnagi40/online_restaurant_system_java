package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restaurant.group.entities.Roles;
import com.restaurant.group.repository.RolesRepository;

@Service
public class RolesService 
{
	@Autowired
	RolesRepository rolerepo;
	
	public List<Roles> getAllRoles()
	{
		List<Roles> roles=rolerepo.findAll();
		return roles;
	}
	
	public Roles getRolebyId(int id)
	{
		Roles role=rolerepo.findById(id).get();
		return role;
	}
}
