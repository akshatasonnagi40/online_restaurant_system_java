package com.restaurant.group.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.restaurant.group.entities.Orders;

@Repository
public interface OrderRepository extends JpaRepository<Orders, Integer> 
{
	@Query(value="SELECT * FROM orders WHERE customer_id=:id",nativeQuery = true)
	public List<Orders> orderbycustomerId(@Param("id") Integer cust_id);
	
	@Query(value = "SELECT max(order_id) FROM orders",nativeQuery = true)
	public int ordercount();
	
}
