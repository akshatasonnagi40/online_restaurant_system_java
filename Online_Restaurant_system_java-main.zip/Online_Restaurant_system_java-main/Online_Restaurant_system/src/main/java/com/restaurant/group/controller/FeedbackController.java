package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Feedback;
import com.restaurant.group.servicelayer.FeedbackService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class FeedbackController 
{
    @Autowired
    FeedbackService fbservice;
    
    @GetMapping("/feedbacks")
    public List<Feedback> getFeedbacks()
    {
    	return fbservice.getAllFeedbacks();
    }
    
    @GetMapping("/feedbackbyrestId")
    public List<Feedback> getFeedbackbyrestId(@RequestParam(value = "rest_id") int rest_id)
    {
    	return fbservice.getfeedbackbyRestoId(rest_id);
    }
    
    @GetMapping("/feedbackbycustId")
    public List<Feedback> getFeedbackbycustId(@RequestParam(value = "cust_id") int cust_id)
    {
    	return fbservice.getfeedbackbycustId(cust_id);
    }
    
    @PostMapping("/addfeedback")
	public void addCustomer(@RequestBody Feedback feedback)
	{
    	fbservice.addFeedback(feedback);
	}
}