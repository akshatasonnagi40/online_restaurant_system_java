package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.OrderDetails;
import com.restaurant.group.servicelayer.OrderDetailsService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class OrderDetailsController 
{
	@Autowired
	OrderDetailsService orddetailservice;
	
	@GetMapping("/orderdetails")
	public List<OrderDetails> getOrderDetials()
	{
		return orddetailservice.getAllOrderDetails();
	}
	
	@GetMapping("/orderdetail/{id}")
	public OrderDetails getOrderDetail(@PathVariable(value = "id") Integer id)
	{
		return orddetailservice.getOrderDetail(id);
	}
	
	@PostMapping("/addorderdetail")
	public void addOrderDetail(@RequestBody List<OrderDetails> orderdetail)
	{
		orddetailservice.addOrderDetails(orderdetail);
	}
	
	@DeleteMapping("/removeorderdetail/{id}")
	public Boolean removeOrderDetail(@PathVariable(value = "id") Integer id)
	{
		if(orddetailservice.removeOrderDetail(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleteorderdetails")
	public boolean deleteOrderDetail(@RequestParam(value = "id") int id)
	{
		return orddetailservice.deleteOrderDetail(id);
	}
	
	
}
