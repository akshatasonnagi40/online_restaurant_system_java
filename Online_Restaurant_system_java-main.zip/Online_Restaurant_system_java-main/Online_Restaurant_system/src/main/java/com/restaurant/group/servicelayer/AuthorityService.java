package com.restaurant.group.servicelayer;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.Authority;
import com.restaurant.group.repository.AuthorityRepository;
import com.restaurant.group.repository.MailService;

@Service
public class AuthorityService {

	@Autowired
	AuthorityRepository authorityRepo;
	 
	private static int otp;
		
	@Autowired
	private MailService emailService; 

	 public Authority authoriryLogin(String email) 
	{
			
		return authorityRepo.authoriryLogin(email);
	}

	public List<Authority> getAllAuthorities()
	{
		List<Authority> authorities=authorityRepo.findAll();
		return authorities ;
	}

	public Authority getAuthorityById(int id)
	{
		Authority authority=authorityRepo.findById(id).get();
		if(authority!=null)
		{
			return authority;
		}
		return new Authority();
	}
	
	public void addAuthority(Authority authority)
	{
		authorityRepo.save(authority);
	}
	
	
	 public int Forgotpassward(String email)
	   {
		 	 authorityRepo.findByEmail(email);
			 otp = new Random().nextInt((999999 - 100000) + 1) + 100000;
			 emailService.sendOtp(email,otp);
			 return otp;
			
	   }
	   
	   public void resetpassward(String email,String pass)
	   {
		   	final Authority authority=authorityRepo.findByEmail(email);
		   	authority.setPassword(pass);	
		   	authorityRepo.save(authority);
			   
	   }
	
	
	public Boolean removeAuthority(int id)
	{
		Boolean status=false;
	
		Authority authority=authorityRepo.findById(id).get();
		if(authority!=null)
		{
			authorityRepo.delete(authority);
			status=true;
		}
		return status;
	}
	
	public Boolean deleteAuthority(int id)
	{
		authorityRepo.deleteById(id);
		return true;
	}
	
	public Boolean updateAuthority(Authority authority,int id)
	{
		Boolean status=false;
	
		Authority author=authorityRepo.getOne(id);
		if(author!=null)
		{
			author.setFirst_nm(authority.getFirst_nm());
			author.setLast_nm(authority.getLast_nm());
			author.setContact_no(authority.getContact_no());
			author.setEmail(authority.getEmail());
			author.setPassword(authority.getPassword());
			authorityRepo.save(author);
			status=true;
		}
		
		return status;
	}
}
