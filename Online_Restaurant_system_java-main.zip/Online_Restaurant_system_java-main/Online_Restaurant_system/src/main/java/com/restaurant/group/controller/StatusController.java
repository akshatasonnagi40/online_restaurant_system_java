package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.group.entities.Status;
import com.restaurant.group.servicelayer.StatusService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class StatusController
{
	@Autowired
	StatusService statservice;
	
	@GetMapping("/status")
	public List<Status> getStatus()
	{
		return statservice.getAllStatus();
	}
	
	@GetMapping("/statusbyid/{id}")
	public Status getStatusbyId(@PathVariable(value = "id") Integer id)
	{
		return statservice.getStatusbyId(id);
	}
}
