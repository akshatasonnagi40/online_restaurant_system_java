package com.restaurant.group.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "status")
public class Status 
{
	@Id
	private int status_id;
	
	@Column
	private String status_name;
	
	
	
	public Status() 
	{
		super();
	}



	public int getStatus_id() {
		return status_id;
	}

	public void setStatus_id(int status_id) {
		this.status_id = status_id;
	}

	

	public String getStatus_name() {
		return status_name;
	}


	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}


	
	
}
