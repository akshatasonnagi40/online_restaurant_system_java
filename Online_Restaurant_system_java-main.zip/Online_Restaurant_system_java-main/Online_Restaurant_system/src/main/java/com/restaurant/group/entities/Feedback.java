package com.restaurant.group.entities;



import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="feedback")

public class Feedback 
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int feedback_id;
	@Column
	private int rating;
	@Column
	private Date date;
	

	@OneToOne
	@JoinColumn(name="customer_id")
	private Customer customer;


	@OneToOne(orphanRemoval = true)
	@JoinColumn(name="order_id")
	private Orders order;

	
	@OneToOne
	@JoinColumn(name="restaurant_id")
	private Restaurant restaurant;
	
	
	public Feedback() 
	{
		super();
	}
	
	

	public int getFeedback_id() {
		return feedback_id;
	}


	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}






	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Orders getOrder() {
		return order;
	}


	public void setOrder(Orders order) {
		this.order = order;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	
	
}
