package com.restaurant.group.servicelayer;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.group.entities.Orders;
import com.restaurant.group.repository.OrderRepository;

@Service
public class OrderService 
{
	@Autowired
	OrderRepository ordrepo;
	public List<Orders> getAllorders()
	{
		List<Orders> orders=ordrepo.findAll();
		return orders;
	}
	
	 public Orders getOrder(int id)
	   {
		 Orders order=ordrepo.findById(id).get();
		 return order;
	   }
	   
	   public Orders addOrder(Orders order)
		{
		   final Orders savedorder= ordrepo.save(order);
		   return savedorder;
		}
	   
	   public List<Orders> getOrderByCustomer(Integer cust_id)
	   {
		   return ordrepo.orderbycustomerId(cust_id);
	   }
		
	   public int ordercount()
	   {
		   return ordrepo.ordercount();
	   }
	   
	   
		public Boolean removeOrder(int id)
		{
			Boolean status=false;
		
			Orders order=ordrepo.getOne(id);
			if(order!=null)
			{
				ordrepo.delete(order);
				status=true;
			}
			return status;
		}
		
		public Boolean deleteOrder(int id)
		{
			ordrepo.deleteById(id);
			return true;
		}
		
		@Transactional
		public Boolean updateOrder(Orders order,int id)
		{
			Boolean status=false;
		
			Orders o=ordrepo.getOne(id);
			if(o!=null)
			{
				o.setDate(order.getDate());
				o.setPayment_mode(order.getPayment_mode());
				o.setPayment_status(order.getPayment_status());
				//o.setTotal_amount(order.getTotal_amount());
				//o.setCustomer(order.getCustomer());
				o.setStatus(order.getStatus());
				//o.setRestaurant(order.getRestaurant());
				ordrepo.save(o);
				status=true;
			}
			
			return status;
		}
}
