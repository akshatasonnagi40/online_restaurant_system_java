package com.restaurant.group.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.restaurant.group.entities.RestaurantProduct;


@Repository
public interface RestaurantProductRepository extends JpaRepository<RestaurantProduct,Integer>
{
	@Query(value = "SELECT * from restaurant_product WHERE restaurant_id=:rest_id",nativeQuery = true)
	public List<RestaurantProduct> RestaurantProductbyRestorantId(@Param("rest_id") int rest_id);
	
	@Query(value = "SELECT * from restaurant_product join products using(product_id) WHERE restaurant_id=:rest_id and category=:veg",nativeQuery = true)
	public List<RestaurantProduct> RestaurantProductbycat(@Param("rest_id") int rest_id,@Param("veg") String veg);
	
	@Query(value = "SELECT * from restaurant_product join products using(product_id) WHERE restaurant_id=:rest_id and category=:nonveg",nativeQuery = true)
	public List<RestaurantProduct> RestaurantProductbycatnon(@Param("rest_id") int rest_id,@Param("nonveg") String nveg);
	
	@Modifying
	@Query(value = "Delete from restaurant_product WHERE r_product_id=:id",nativeQuery = true)
	public void deleteRestaurantProduct(@Param("id") int id);

}
