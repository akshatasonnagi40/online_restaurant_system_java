package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.Products;
import com.restaurant.group.repository.ProductRepository;

@Service
public class ProductService
{
	@Autowired
	ProductRepository prorepo;
	
	public List<Products> getAllProducts()
	{
		List<Products> products=prorepo.findAll();
		return products;
	}
	
	public Products getProductbyId(int id)
	{
		Products product=prorepo.findById(id).get();
		return product;
	}
	
	 public Products addProduct(Products product)
		{
		 	final Products savedpro= prorepo.save(product);
		 	return savedpro;
		}
		
		public Boolean removeProduct(int id)
		{
			Boolean status=false;
		
			Products product=prorepo.getOne(id);
			if(product!=null)
			{
				prorepo.delete(product);
				status=true;
			}
			return status;
		}
		
		public Boolean deleteProduct(int id)
		{
			prorepo.deleteById(id);
			return true;
		}
		
		public Boolean updateProduct(Products product,int id)
		{
			Boolean status=false;
		
			Products p=prorepo.getOne(id);
			if(p!=null)
			{
				p.setProduct_nm(product.getProduct_nm());
				p.setCategory(product.getCategory());
				p.setSubcategory(product.getSubcategory());
				p.setProduct_desc(product.getProduct_desc());
				prorepo.save(p);
				status=true;
			}
			
			return status;
		}
}
