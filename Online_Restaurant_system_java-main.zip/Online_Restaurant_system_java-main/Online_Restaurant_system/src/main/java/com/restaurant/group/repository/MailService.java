package com.restaurant.group.repository;

public interface MailService 
{
	public void sendOtp(String email, int otp);
}
