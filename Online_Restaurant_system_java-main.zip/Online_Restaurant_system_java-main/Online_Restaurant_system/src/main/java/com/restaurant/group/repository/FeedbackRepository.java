package com.restaurant.group.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.restaurant.group.entities.Feedback;



@Repository
public interface FeedbackRepository extends JpaRepository<Feedback,Integer>
{
	@Query(value = "SELECT * from feedback WHERE restaurant_id=:rest_id",nativeQuery = true)
	public List<Feedback> feedbackbyRestaurantId(@Param("rest_id") Integer rest_id);
	
	@Query(value = "SELECT * from feedback WHERE customer_id=:cust_id",nativeQuery = true)
	public List<Feedback> feedbackbycustomerId(@Param("cust_id") Integer cust_id);
	
}



