package com.restaurant.group.entities;



import java.sql.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name = "orders")
public class Orders 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int order_id;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column
	private Date date;
	
	@Column
	private int total_amount;
	
	@Column
	private String payment_mode;
	
	@Column
	private String payment_status;
	

	@OneToOne(orphanRemoval = true)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	

	@OneToOne
	@JoinColumn(name = "status_id")
	private Status status;
	
	
	@OneToOne(orphanRemoval = true)
	@JoinColumn(name = "restaurant_id",nullable = true,insertable = true,updatable = true)
	private Restaurant restaurant;
	

	
	public Orders() {
		super();
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	/*public Set<OrderDetails> getOrderdetails() {
		return orderdetails;
	}

	public void setOrderdetails(Set<OrderDetails> orderdetails) {
		this.orderdetails = orderdetails;
	}*/
	
	
	
}
