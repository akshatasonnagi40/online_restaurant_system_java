package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.Feedback;
import com.restaurant.group.repository.FeedbackRepository;


@Service
public class FeedbackService
{
   @Autowired
   FeedbackRepository fbrepo;
   
   public List<Feedback> getAllFeedbacks()
   {
	   List<Feedback> feedbacks=fbrepo.findAll();
	   return feedbacks;
   }
   
   public void addFeedback(Feedback feedback)
	{
	   fbrepo.save(feedback);
	}
   public List<Feedback> getfeedbackbyRestoId(Integer rest_id)
   {
	   return fbrepo.feedbackbyRestaurantId(rest_id);
   }
   
   public List<Feedback> getfeedbackbycustId(Integer cust_id)
   {
	   return fbrepo.feedbackbycustomerId(cust_id);
   }
}