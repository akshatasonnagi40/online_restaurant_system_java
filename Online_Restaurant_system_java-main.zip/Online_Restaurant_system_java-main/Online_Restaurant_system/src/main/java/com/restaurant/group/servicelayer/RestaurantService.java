package com.restaurant.group.servicelayer;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.Restaurant;
import com.restaurant.group.repository.RestaurantRepository;


@Service
public class RestaurantService
{
  
	@Autowired
	RestaurantRepository restrepo;
	
	public List<Restaurant> getAllRestaurants()
	{
		List<Restaurant> restaurants=restrepo.findAll();
		return restaurants;
	}
   
	 public Restaurant getRestaurant(int cid)
	   {
		 Restaurant restaurant=restrepo.findById(cid).get();
		   return restaurant;
	   }
	   
	   public Restaurant addRestaurant(Restaurant restaurant)
		{
		   Restaurant rest=restrepo.save(restaurant);
		   return rest;
		}
		
		public Boolean removeRestaurant(int id)
		{
			Boolean status=false;
		
			Restaurant restaurant=restrepo.getOne(id);
			if(restaurant!=null)
			{
				restrepo.delete(restaurant);
				status=true;
			}
			return status;
		}
		
		public Boolean deleteRestaurant(int id)
		{
			restrepo.deleteById(id);
			return true;
		}
		

		public Boolean updateRestaurant(Restaurant restaurant,int id)
		{
			Boolean status=false;
		
			Restaurant res=restrepo.getOne(id);
			if(res!=null)
			{
				res.setRestaurant_nm(restaurant.getRestaurant_nm());
				res.setAddress(restaurant.getAddress());
				res.setGstin(restaurant.getGstin());
				res.setReg_date(restaurant.getReg_date());
				res.setValidity_date(restaurant.getValidity_date());
				restrepo.save(res);
				status=true;
			}
			
			return status;
		}
}
