package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.RestaurantProduct;
import com.restaurant.group.servicelayer.RestaurantProductService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class RestaurantProductController 
{
	@Autowired
	RestaurantProductService restoproservice;
	
	@GetMapping("/restaurantproducts")
	public List<RestaurantProduct> getRestaurantProducts()
	{
		return restoproservice.getAllRestaurantProducts();
	}
	@GetMapping("/restaurantproduct/{id}")
	public RestaurantProduct getRestaurantProduct(@PathVariable(value = "id") Integer id)
	{
		return restoproservice.getRestaurantProduct(id);
	}
	
	@GetMapping("/restaurantproductbyrestoid")
	public List<RestaurantProduct> getProducts(@RequestParam(value = "rest_id") int rest_id)
	{
		return restoproservice.RestaurantProductbyRestorantId(rest_id);
	}
	
	@GetMapping("/restaurantproductbyvegcat")
	public List<RestaurantProduct> RestaurantProductbycat(@RequestParam(value = "rest_id") int rest_id)
	{
		String cat="veg";
		return restoproservice.RestaurantProductbycat(rest_id,cat);
	}
	
	@GetMapping("/restaurantproductbynonveg")
	public List<RestaurantProduct> RestaurantProductbycatnon(@RequestParam(value = "rest_id") int rest_id)
	{
		String cat="non veg";
		return restoproservice.RestaurantProductbycat(rest_id,cat);
	}
	
	@PostMapping("/addrestaurantproduct")
	public void addRestaurantProduct(@RequestBody RestaurantProduct respro)
	{
		restoproservice.addRestaurantProduct(respro);
	}
	
	@DeleteMapping("/removerestaurantproduct")
	public Boolean removeRestaurantProduct(@RequestParam(value = "id") Integer id)
	{
		if(restoproservice.removeRestaurantProduct(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleterestaurantproduct")
	public boolean deleteRestaurantProduct(@RequestParam(value = "id") int id)
	{
		return restoproservice.deleteRestaurantProduct(id);
	}
	
	@PutMapping("/updaterestaurantproduct/{id}")
	public Boolean updateRestaurantProduct(@RequestBody RestaurantProduct respro, @PathVariable(value = "id") Integer id)
	{
		if(restoproservice.updateRestaurantProduct(respro, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
