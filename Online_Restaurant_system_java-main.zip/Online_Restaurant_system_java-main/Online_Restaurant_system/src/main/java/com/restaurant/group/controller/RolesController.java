package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.group.entities.Roles;
import com.restaurant.group.servicelayer.RolesService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class RolesController 
{
	@Autowired
	RolesService roleservice;
	
	@GetMapping("/roles")
	public List<Roles> getRoles()
	{
		return roleservice.getAllRoles();
	}
	
	@GetMapping("/role/{id}")
	public Roles getRolebyId(@PathVariable(value = "id") Integer id)
	{
		return roleservice.getRolebyId(id);
	}
}
