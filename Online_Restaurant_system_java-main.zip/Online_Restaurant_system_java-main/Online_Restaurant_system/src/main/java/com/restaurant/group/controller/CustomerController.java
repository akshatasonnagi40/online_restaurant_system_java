package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Customer;
import com.restaurant.group.servicelayer.CustomerService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class CustomerController 
{
	@Autowired
	CustomerService custservice;
	
	@GetMapping("/customers")
	public List<Customer> getCustomers()
	{
		return custservice.getAllCustomers();
	}
	
	@GetMapping("/customer/{id}")
	public Customer getCustomer(@PathVariable(value = "id") Integer id)
	{
		return custservice.getCustomer(id);
	}
	
	@GetMapping("/login")
	public Customer customerLogin(@RequestParam String email,@RequestParam String password)
	{
		Customer customer=custservice.customerLogin(email);
		if(customer!=null)
		{
			return customer;
		}
		else
		{
			return new Customer();
		}
		
	}
	
	@GetMapping("/forgotpassword/{email}")
	public int GetOTP(@PathVariable(value = "email") String email)
	{
		return custservice.Forgotpassward(email);		
	}
	
	@PostMapping("/addcustomer")
	public void addCustomer(@RequestBody Customer customer)
	{
		custservice.addCustomer(customer);
	}
	
	@GetMapping("/resetpassword")
	public void addCustomer(@RequestParam String email,@RequestParam String pass)
	{
		custservice.resetpassward(email, pass);
	
	}
	
	@DeleteMapping("/removecustomer/{id}")
	public Boolean removeCustomer(@PathVariable(value = "id") Integer id)
	{
		if(custservice.removeCustomer(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@PutMapping("/updatecustomer/{id}")
	public Boolean updateCustomer(@RequestBody Customer customer, @PathVariable(value = "id") Integer id)
	{
		if(custservice.updateCustomer(customer, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
