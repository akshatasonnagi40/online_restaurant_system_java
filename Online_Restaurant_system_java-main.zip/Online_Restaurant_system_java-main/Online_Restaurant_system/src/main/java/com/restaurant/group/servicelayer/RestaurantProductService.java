package com.restaurant.group.servicelayer;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.group.entities.RestaurantProduct;
import com.restaurant.group.repository.RestaurantProductRepository;


@Service
public class RestaurantProductService
{
	@Autowired
	RestaurantProductRepository restprorepo;
	
	public List<RestaurantProduct> getAllRestaurantProducts()
	{
		List<RestaurantProduct> restaurantproducts=restprorepo.findAll();
		return restaurantproducts;
	}
   
	 public RestaurantProduct getRestaurantProduct(int cid)
	   {
		 	RestaurantProduct respro=restprorepo.findById(cid).get();
		   return respro;
	   }
	   
	 public List<RestaurantProduct> RestaurantProductbyRestorantId(int rest_id)
	 {
		 List<RestaurantProduct> prolist=restprorepo.RestaurantProductbyRestorantId(rest_id);
		 return prolist;
	 }
	 
	 public List<RestaurantProduct> RestaurantProductbycat(int rest_id,String veg)
	 {
		 List<RestaurantProduct> prolist=restprorepo.RestaurantProductbycat(rest_id,veg);
		 return prolist;
	 }
	 
	 public List<RestaurantProduct> RestaurantProductbycatnon(int rest_id,String nveg)
	 {
		 List<RestaurantProduct> prolist=restprorepo.RestaurantProductbycatnon(rest_id,nveg);
		 return prolist;
	 }
	 
	  public void addRestaurantProduct(RestaurantProduct respro)
	  {
		 restprorepo.save(respro);
	  }
	  
	  
		
	 public Boolean removeRestaurantProduct(int id)
		{
			Boolean status=false;
		
			RestaurantProduct respro=restprorepo.findById(id).get();
			if(respro!=null)
			{
				restprorepo.delete(respro);
				status=true;
			}
			return status;
		}
		
	 @Transactional
		public Boolean deleteRestaurantProduct(int id)
		{
			restprorepo.deleteRestaurantProduct(id);
			return true;
		}
		
		public Boolean updateRestaurantProduct(RestaurantProduct respro,int id)
		{
			Boolean status=false;
		
			RestaurantProduct res=restprorepo.getOne(id);
			if(res!=null)
			{
				res.setUnit_price(respro.getUnit_price());
				//res.setProduct(respro.getProduct());
				//res.setRestaurant(respro.getRestaurant());
				restprorepo.save(res);
				status=true;
			}
			
			return status;
		}
}
