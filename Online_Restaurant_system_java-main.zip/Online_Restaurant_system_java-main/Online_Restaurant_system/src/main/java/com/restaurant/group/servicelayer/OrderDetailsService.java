package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.group.entities.OrderDetails;
import com.restaurant.group.repository.OrderDetailsRepository;

@Service
public class OrderDetailsService 
{
	@Autowired
	OrderDetailsRepository orddetailrepo;
	
	public List<OrderDetails> getAllOrderDetails()
	{
		List<OrderDetails> orderdetails=orddetailrepo.findAll();
		return orderdetails;
	}
	
	 public OrderDetails getOrderDetail(int id)
	   {
		 OrderDetails orddetail=orddetailrepo.findById(id).get();
		   return orddetail;
	   }
	   
	 @Transactional
	   public void addOrderDetails(List<OrderDetails> orddetail)
		{
		   for(OrderDetails ord: orddetail)
		   {
			   orddetailrepo.save(ord);
		   }
		}
		
		public Boolean removeOrderDetail(int id)
		{
			Boolean status=false;
		
			OrderDetails orddetail=orddetailrepo.getOne(id);
			if(orddetail!=null)
			{
				orddetailrepo.delete(orddetail);
				status=true;
			}
			return status;
		}
		
		public Boolean deleteOrderDetail(int id)
		{
			orddetailrepo.deleteById(id);
			return true;
		}
		
		/*public Boolean updateOrderDetail(OrderDetails orddetail,int id)
		{
			Boolean status=false;
		
			OrderDetails or=orddetailrepo.getOne(id);
			if(or!=null)
			{
				or.setQuantity(orddetail.getQuantity());
				or.setAmount(orddetail.getAmount());
				or.setRestaurantProduct(orddetail.getRestaurantProduct());
				or.setOrders(orddetail.getOrders());
				orddetailrepo.save(or);
				status=true;
			}
			
			return status;
		}*/
}
