package com.restaurant.group.servicelayer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.restaurant.group.repository.MailService;

@Service
public class EmailService implements MailService 
{

	
		@Autowired
		private JavaMailSender mailSender;
		
		@Override
		public void sendOtp(String email, int otp) 
		{
			SimpleMailMessage message = new SimpleMailMessage();
			message.setTo(email);
			message.setSubject("Otp from Taste Ride Services");
			message.setText("Dear Customer\n\n" + "Your Otp : " + otp);
			mailSender.send(message);
			System.out.println("emaill sent successfully");
		}

}


