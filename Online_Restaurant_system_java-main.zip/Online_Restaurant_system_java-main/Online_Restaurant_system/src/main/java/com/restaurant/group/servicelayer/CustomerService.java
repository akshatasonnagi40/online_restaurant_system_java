package com.restaurant.group.servicelayer;


import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.Customer;
import com.restaurant.group.repository.CustomerRepository;
import com.restaurant.group.repository.MailService;

@Service
public class CustomerService 
{

   @Autowired
   CustomerRepository cusrepo;
   
   private static int otp;
	
   @Autowired
	private MailService emailService; 
	
	   
   public Customer customerLogin(String email) 
	{
		
		return cusrepo.customerLogin(email);
	}

   
   public List<Customer> getAllCustomers()
   {
	   List<Customer> customers=cusrepo.findAll();
	   return customers;
   }
   
   public int Forgotpassward(String email)
   {
	   	 cusrepo.findByEmail(email);
		 otp = new Random().nextInt((999999 - 100000) + 1) + 100000;
		 emailService.sendOtp(email,otp);
		 return otp;
		
   }
   
   public void resetpassward(String email,String pass)
   {
	   	 final Customer customer=cusrepo.findByEmail(email);
	   	 customer.setPassword(pass);	
		 cusrepo.save(customer);
		   
   }
   
   public Customer getCustomer(int cid)
   {
	   Customer customer=cusrepo.findById(cid).get();
	   return customer;
   }
   
   public void addCustomer(Customer customer)
	{
	   cusrepo.save(customer);
	}
	
	public Boolean removeCustomer(int id)
	{
		Boolean status=false;
	
		Customer customer=cusrepo.getOne(id);
		if(customer!=null)
		{
			cusrepo.delete(customer);
			status=true;
		}
		return status;
	}
	
	public Boolean updateCustomer(Customer customer,int id)
	{
		Boolean status=false;
	
		Customer c=cusrepo.getOne(id);
		if(c!=null)
		{
			c.setFirst_nm(customer.getFirst_nm());
			c.setLast_nm(customer.getLast_nm());
			c.setContact(customer.getContact());
			c.setEmail(customer.getEmail());
			c.setAddress(customer.getAddress());
			c.setPassword(customer.getPassword());
			cusrepo.save(c);
			status=true;
		}
		
		return status;
	}
}