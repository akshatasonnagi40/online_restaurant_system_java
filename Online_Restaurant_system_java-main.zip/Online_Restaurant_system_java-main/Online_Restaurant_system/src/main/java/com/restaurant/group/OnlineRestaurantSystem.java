package com.restaurant.group;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.restaurant.group.*")
public class OnlineRestaurantSystem 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(OnlineRestaurantSystem.class, args);
	}

	
}
