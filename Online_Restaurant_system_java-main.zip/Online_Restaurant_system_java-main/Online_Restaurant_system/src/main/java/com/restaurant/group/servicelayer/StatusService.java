package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restaurant.group.entities.Status;
import com.restaurant.group.repository.StatusRepository;

@Service
public class StatusService 
{
	@Autowired
	StatusRepository statrepo;
	
	public List<Status> getAllStatus()
	{
		List<Status> status=statrepo.findAll();
		return status;
	}
	
	public Status getStatusbyId(int id)
	{
		Status status=statrepo.findById(id).get();
		return status;
	}
}
