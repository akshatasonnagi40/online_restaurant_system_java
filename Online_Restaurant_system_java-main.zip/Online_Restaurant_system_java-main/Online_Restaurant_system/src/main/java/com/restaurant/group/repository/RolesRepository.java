package com.restaurant.group.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.restaurant.group.entities.Roles;

@Repository
public interface RolesRepository extends JpaRepository<Roles, Integer> 
{

}
