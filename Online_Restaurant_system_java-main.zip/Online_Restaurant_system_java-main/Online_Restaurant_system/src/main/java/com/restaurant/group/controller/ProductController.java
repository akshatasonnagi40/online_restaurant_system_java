package com.restaurant.group.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Products;
import com.restaurant.group.servicelayer.ProductService;
import com.restaurant.group.servicelayer.RestaurantProductService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class ProductController 
{
	@Autowired
	ProductService proservice;
	
	@Autowired
	RestaurantProductService rpservice;
	
	@GetMapping("/products")
	public List<Products> getProducts()
	{
		return proservice.getAllProducts();
	}
	
	@GetMapping("/product")
	public Products getProducts(@RequestParam("id") int id)
	{
		return proservice.getProductbyId(id);
	}
	
	@PostMapping("/addproduct")
	public Products addProduct(@RequestBody Products product)
	{
		Products savedpro=proservice.addProduct(product);
		return savedpro;		
	}
	
	@DeleteMapping("/removeproduct/{id}")
	public Boolean removeProduct(@PathVariable(value = "id") Integer id)
	{
		if(proservice.removeProduct(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleteproduct")
	public boolean deleteRestaurantProduct(@RequestParam(value = "id") int id)
	{
		return proservice.deleteProduct(id);
	}
	
	@PutMapping("/updateproduct/{id}")
	public Boolean updateProduct(@RequestBody Products product, @PathVariable(value = "id") Integer id)
	{
		if(proservice.updateProduct(product, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
