package com.restaurant.group.servicelayer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.restaurant.group.entities.WebsiteAdmin;
import com.restaurant.group.repository.WebsiteAdminRepository;

@Service
public class WebsiteAdminService 
{

	@Autowired
	WebsiteAdminRepository websiteAdminRepo;
	
	public WebsiteAdmin WebsiteAdminLogin(String user_id) 
	{
		
		return websiteAdminRepo.webAdminLogin(user_id);
	}

	public List<WebsiteAdmin> getWebsiteAdmins() 
	{
		
		return websiteAdminRepo.findAll();
	}
	
	 public void addWebsiteAdmin(WebsiteAdmin admin)
		{
		 websiteAdminRepo.save(admin);
		}
		
		public Boolean removeWebsiteAdmin(int id)
		{
			Boolean status=false;
		
			WebsiteAdmin admin=websiteAdminRepo.findById(id).get();
			if(admin!=null)
			{
				websiteAdminRepo.delete(admin);
				status=true;
			}
			return status;
		}
		
		public Boolean updateWebsiteAdmin(WebsiteAdmin ad,int id)
		{
			Boolean status=false;
		
			WebsiteAdmin admin=websiteAdminRepo.getOne(id);
			if(admin!=null)
			{
				admin.setFirst_nm(ad.getFirst_nm());
				admin.setLast_nm(ad.getLast_nm());
				admin.setContact(ad.getContact());
				admin.setEmail(ad.getEmail());
				admin.setUser_id(ad.getUser_id());
				admin.setPassword(ad.getPassword());
				websiteAdminRepo.save(admin);
				status=true;
			}
			
			return status;
		}
}
