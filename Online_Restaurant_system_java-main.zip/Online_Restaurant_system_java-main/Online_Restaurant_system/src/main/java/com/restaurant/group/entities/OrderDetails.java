package com.restaurant.group.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="order_details")
public class OrderDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int or_detail_id;

	@Column
	private int amount;

	@Column
	private int quantity;



	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="order_id",nullable = true,insertable = true,updatable = true)
	private Orders order;	
	

	@OneToOne(orphanRemoval = true)
	@JoinColumn(name="r_product_id",nullable = true,insertable = true,updatable = true)
	private RestaurantProduct rs;
	
	

	public OrderDetails() {
		super();
	}

	public int getOr_detail_id() {
		return or_detail_id;
	}

	public void setOr_detail_id(int or_detail_id) {
		this.or_detail_id = or_detail_id;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Orders getOrder() {
		return order;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}

	public RestaurantProduct getRs() {
		return rs;
	}

	public void setRs(RestaurantProduct rs) {
		this.rs = rs;
	}

	
	
	
	
}
