package com.restaurant.group.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Authority;
import com.restaurant.group.servicelayer.AuthorityService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class AuthorityController
{
	@Autowired
	AuthorityService authorityService;

	@GetMapping("/authorities")
	public List<Authority> getAuthorities() 
	{
		return authorityService.getAllAuthorities();
	}
	
	@GetMapping("/getauthority")
	public Authority getAuthority(@RequestParam Integer id) 
	{
		return authorityService.getAuthorityById(id);
	}
	
	@GetMapping("/authoritylogin")
	public Authority authoriryLogin(@RequestParam String email,@RequestParam String password)
	{
		Authority authority=authorityService.authoriryLogin(email);
		if(authority!=null)
		{
			return authority;
		}
		else
		{
			return new Authority();
		}
	}
	
	@PostMapping("/addauthority")
	public void addAuthority(@RequestBody Authority authority)
	{
		authorityService.addAuthority(authority);
	}
	
	@GetMapping("/forgotauthoritypassword/{email}")
	public int GetOTP(@PathVariable(value = "email") String email)
	{
		return authorityService.Forgotpassward(email);		
	}
	
	@GetMapping("/resetauthoritypassword")
	public void addauthority(@RequestParam String email,@RequestParam String pass)
	{
		authorityService.resetpassward(email, pass);
	
	}
	
	@DeleteMapping("/removeauthority/{id}")
	public Boolean removeAuthority(@PathVariable(value = "id") Integer id)
	{
		if(authorityService.removeAuthority(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleteauthority")
	public boolean deleteProduct(@RequestParam(value = "id") int id)
	{
		return authorityService.deleteAuthority(id);
	}
	
	@PutMapping("/updateauthority/{id}")
	public Boolean updateAuthority(@RequestBody Authority authority, @PathVariable(value = "id") Integer id)
	{
		if(authorityService.updateAuthority(authority,id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
}

