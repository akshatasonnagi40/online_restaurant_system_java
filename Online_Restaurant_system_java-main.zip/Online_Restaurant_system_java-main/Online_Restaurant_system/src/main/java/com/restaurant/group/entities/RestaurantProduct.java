package com.restaurant.group.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="restaurant_product")
public class RestaurantProduct 
{
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int r_product_id;
	
	@Column
	private int unit_price;
	
	
	
	@OneToOne(orphanRemoval = true)
	@JoinColumn(name="product_id",nullable = false)
	private Products product;
	
	

	
	@OneToOne(orphanRemoval = true)
	@JoinColumn(name = "restaurant_id",nullable = false)
	private Restaurant restaurant;
	
	
	

	public RestaurantProduct() {
		super();
	}

	

	public int getR_product_id() {
		return r_product_id;
	}



	public void setR_product_id(int r_product_id) {
		this.r_product_id = r_product_id;
	}



	public int getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(int unit_price) {
		this.unit_price = unit_price;
	}

	public Products getProduct() {
		return product;
	}

	public void setProduct(Products product) {
		this.product = product;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}


	
}
