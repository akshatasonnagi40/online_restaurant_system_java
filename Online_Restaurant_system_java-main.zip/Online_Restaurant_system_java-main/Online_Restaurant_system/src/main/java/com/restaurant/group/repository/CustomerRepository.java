package com.restaurant.group.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.restaurant.group.entities.Customer;



@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer>
{
	@Query(value = "SELECT * FROM customer WHERE email = :email",nativeQuery = true)
	public Customer customerLogin(@Param("email") String email);
	
	
	public Customer findByEmail(String email);
}
