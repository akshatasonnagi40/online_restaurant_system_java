package com.restaurant.group.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.restaurant.group.entities.Orders;
import com.restaurant.group.servicelayer.OrderDetailsService;
import com.restaurant.group.servicelayer.OrderService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class OrderController 
{
	@Autowired
	OrderService ordservice;
	
	@Autowired
	OrderDetailsService detailservice;
	
	@GetMapping("/orders")
	public List<Orders> getOrders()
	{
		return ordservice.getAllorders();
	}
	
	@GetMapping("/order/{order_id}")
	public Orders getOrder(@PathVariable(value = "order_id") Integer id)
	{
		return ordservice.getOrder(id);
	}
	
	@GetMapping("/orderbycustomer")
	public List<Orders> getOrderbycustomer(@RequestParam(value = "cust_id") Integer id)
	{
		return ordservice.getOrderByCustomer(id);
	} 
	
	@GetMapping("/ordercount")
	public Integer getordercount()
	{
		return ordservice.ordercount();
	}
	
	@Transactional
	@PostMapping("/addorder")
	public Orders addOrder(@RequestBody Orders order)
	{
		Orders savedorder=ordservice.addOrder(order);
		return savedorder;
	}
	
	@DeleteMapping("/removeorder/{id}")
	public Boolean removeOrder(@PathVariable(value = "id") Integer id)
	{
		if(ordservice.removeOrder(id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@DeleteMapping("/deleteorder")
	public boolean deleteProduct(@RequestParam(value = "id") int id)
	{
		return ordservice.deleteOrder(id);
	}
	
	@PutMapping("/updateorder/{id}")
	public Boolean updateOrders(@RequestBody Orders order, @PathVariable(value = "id") Integer id)
	{
		if(ordservice.updateOrder(order, id))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
