package com.restaurant.group.entities;


import javax.persistence.*;


import com.fasterxml.jackson.annotation.JsonFormat;
import java.sql.Date;


@Entity
@Table(name="restaurant")
public class Restaurant
{
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restaurant_id;

	@Column
	private String address;

	@JsonFormat(pattern="yyyy-MM-dd")
	@Column
	private Date reg_date;

	@Column
	private String restaurant_nm;

	 @JsonFormat(pattern="yyyy-MM-dd")
	@Column
	private Date validity_date;
	 
	 @Column
	 private String gstin;
	 
	

	
	public Restaurant() 
	{
		
	}

	
	public int getRestaurant_id() {
		return restaurant_id;
	}

	public void setRestaurant_id(int restaurant_id) {
		this.restaurant_id = restaurant_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	public String getGstin() {
		return gstin;
	}


	public void setGstin(String gstin) {
		this.gstin = gstin;
	}


	public Date getReg_date() {
		return reg_date;
	}

	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}

	public String getRestaurant_nm() {
		return restaurant_nm;
	}

	public void setRestaurant_nm(String restaurant_nm) {
		this.restaurant_nm = restaurant_nm;
	}

	public Date getValidity_date() {
		return validity_date;
	}

	public void setValidity_date(Date validity_date) {
		this.validity_date = validity_date;
	}


		


}
