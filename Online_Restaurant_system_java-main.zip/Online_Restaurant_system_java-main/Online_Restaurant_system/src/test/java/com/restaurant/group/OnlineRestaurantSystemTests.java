package com.restaurant.group;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineRestaurantSystemTests {

	@Test
	void contextLoads() {
	}

}
